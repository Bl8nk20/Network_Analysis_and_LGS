﻿using Data_Read_and_Write;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Read_and_Write.Data_Stuff;

/// <summary>
/// 
/// </summary>
public class DataGathering
{
    public double Voltage { get; set; }
    public double Resistance { get; set; }    
    public double Current { get; set; }

}
