﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Read_and_Write.Data_Stuff;

internal class Reading
{

}
