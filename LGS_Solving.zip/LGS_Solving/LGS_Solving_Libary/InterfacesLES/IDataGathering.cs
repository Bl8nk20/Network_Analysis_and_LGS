﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LGS_Solving_Libary.Interfaces
{
    public interface IDataGathering<T>
    {
        T A_Matrix_Creating();
    }
}
